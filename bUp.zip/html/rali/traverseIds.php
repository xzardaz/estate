<?php



//include("./phpsquery/phpQuery-onefile.php");
//$cont=file_get_contents("sample.html");

?>
