<?php


	echo 123;
class User
{
	private $uName;
	private function hihi(){echo "hello";}
}





private function getPath(echo vim:)
{

}


$ivan=new User();

var_dump($ivan);

	
