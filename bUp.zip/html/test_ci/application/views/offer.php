
	<?php
		var_dump($offer->area);
	?>
<div class="offer">
	<div class="imageWrap">
		<img src="<?=$offer->photo;?>" alt="image" width="180" height="180"  />
	</div>
	<div class="ofrAttrs">
		<div class="ofrLoc">
			<div>type(<?=$offer->type;?>): location here</div>
		</div>
		<div class="ofrBrief">
			<p>
			a sl kdfhk ja sdfhk sja asdf afsdfa sdf asdf asdf asd fasdfdfhasdjkfhk ajsdfhwwk asasdf asdf asdf asdfasdf asdfasdf asasdfasd asdfasdf asdfasdfsdf asdfasdf fsadfsad sdfaf asd
			</p>
		</div>
		<div class="ofrProps">
			<div class="ofrBottom">
				<div class="ofrBottomProps">
					<div class="ofrCurrentProp"><b>$</b><?=$offer->price;?></div>
					<div class="ofrCurrentProp"><?=$offer->rooms;?> rooms</div>
					<div class="ofrCurrentProp"><?=$offer->rooms;?>m2</div>
				</div>
				<div class="ofrAgencyLogo">
					<img src="<?=$offer->aglogo;?>" alt="company" height="50" width="150" />
				</div>
			</div>
		</div>
	</div>
</div>
