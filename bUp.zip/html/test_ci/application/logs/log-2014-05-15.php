<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-05-15 09:02:39 --> Severity: Notice  --> Undefined property: FAQ::$offers_fetch /var/www/html/test_ci/system/core/Model.php 51
ERROR - 2014-05-15 09:03:53 --> Severity: Notice  --> Undefined property: FAQ::$db /var/www/html/test_ci/system/core/Model.php 51
ERROR - 2014-05-15 10:53:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/test_ci/application/controllers/faq.php 42
ERROR - 2014-05-15 10:54:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/test_ci/application/controllers/faq.php 42
ERROR - 2014-05-15 10:59:34 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/controllers/faq.php 44
ERROR - 2014-05-15 10:59:34 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/controllers/faq.php 45
ERROR - 2014-05-15 10:59:34 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/controllers/faq.php 46
ERROR - 2014-05-15 11:07:33 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:08:18 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:08:20 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:08:21 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:08:21 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:08:21 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:39 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:40 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:40 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:40 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:40 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:41 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:41 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:41 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:41 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:41 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:42 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:09:42 --> Severity: Warning  --> require_once(/var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php): failed to open stream: Permission denied /var/www/html/test_ci/system/database/DB.php 140
ERROR - 2014-05-15 11:10:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:10:40 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/controllers/faq.php 44
ERROR - 2014-05-15 11:10:40 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/controllers/faq.php 45
ERROR - 2014-05-15 11:10:40 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/controllers/faq.php 46
ERROR - 2014-05-15 11:11:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:11:32 --> Query error: Table 'estate.faq' doesn't exist
ERROR - 2014-05-15 11:11:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:11:47 --> Query error: Unknown column 'priority' in 'order clause'
ERROR - 2014-05-15 11:12:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:12:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:12:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:12:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:12:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:14:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:17:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:17:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:17:18 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:18 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:18 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:17:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:34 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:17:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:18:56 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 11:18:57 --> Severity: Notice  --> Undefined property: FAQ::$db /var/www/html/test_ci/system/core/Model.php 51
ERROR - 2014-05-15 11:20:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:21:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:37:00 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/models/faq_mdl.php 15
ERROR - 2014-05-15 11:37:00 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 24
ERROR - 2014-05-15 11:37:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:37:39 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 15
ERROR - 2014-05-15 11:37:39 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 24
ERROR - 2014-05-15 11:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:38:00 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:38:00 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:38:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:38:22 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:38:22 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:02 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:02 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:36 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:36 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:38 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:38 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:38 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:38 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:39 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:39 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:39 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:39 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:39 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:39 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:40 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:40 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:40 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:40 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:40 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:40 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:40 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:40 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:39:54 --> Severity: Notice  --> Undefined index: nice /var/www/html/test_ci/application/models/faq_mdl.php 16
ERROR - 2014-05-15 11:39:54 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 25
ERROR - 2014-05-15 11:40:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:40:28 --> Severity: Notice  --> Undefined variable: query /var/www/html/test_ci/application/models/faq_mdl.php 24
ERROR - 2014-05-15 11:40:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:41:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:41:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:41:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:41:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:41:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:41:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:41:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:41:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:42:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:42:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:42:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:42:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:42:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:42:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:44:03 --> 404 Page Not Found --> admin/index
ERROR - 2014-05-15 11:44:31 --> 404 Page Not Found --> admin/index
ERROR - 2014-05-15 11:44:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:45:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:45:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:46:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:46:11 --> 404 Page Not Found --> admin/ok
ERROR - 2014-05-15 11:46:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:47:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:47:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 11:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:09:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:13:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:13:48 --> Query error: FUNCTION estate.CANCAT does not exist
ERROR - 2014-05-15 12:14:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:14:26 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:14:26 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:14:26 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:15:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:15:51 --> Severity: Notice  --> Undefined property: Admin::$faq_mdl /var/www/html/test_ci/application/controllers/admin.php 23
ERROR - 2014-05-15 12:15:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:17:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:17:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:17:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:19:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:19:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:19:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:21:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:21:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:23:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:24:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:25:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:25:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:25:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:26:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:26:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:27:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:27:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:28:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:28:38 --> Severity: Notice  --> Undefined index: mdId /var/www/html/test_ci/application/views/faqa.php 32
ERROR - 2014-05-15 12:30:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:31:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:31:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:31:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:31:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:34:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:34:30 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:34:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:34:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:34:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:34:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:34:37 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:34:37 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:34:37 --> 404 Page Not Found --> imgs
ERROR - 2014-05-15 12:34:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:34:41 --> Severity: Notice  --> Undefined property: Admin::$faq_mdl /var/www/html/test_ci/application/controllers/admin.php 32
ERROR - 2014-05-15 12:34:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:36:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:38:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:38:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:39:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:40:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:40:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:40:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:40:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:40:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:43:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:44:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:44:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:44:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:44:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:44:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:50:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:53:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:53:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:53:48 --> 404 Page Not Found --> admin/js
ERROR - 2014-05-15 12:53:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:53:49 --> 404 Page Not Found --> admin/js
ERROR - 2014-05-15 12:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:56:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 12:59:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:00:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:00:21 --> 404 Page Not Found --> query/index
ERROR - 2014-05-15 13:01:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:01:08 --> 404 Page Not Found --> query/index
ERROR - 2014-05-15 13:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:01:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:02:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:02:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:03:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:03:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:03:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:03:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:03:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:04:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:04:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:04:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:04:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:05:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:05:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:08:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:08:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:11:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:12:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:12:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:12:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:13:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:13:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:13:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:15:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:15:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:15:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:16:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:16:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:16:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 13:16:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:17:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:18:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:18:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:20:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:21:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:26:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:27:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:28:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:33:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:38:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:39:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:47:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:47:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:47:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:48:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 16:48:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 19:56:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 19:56:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 19:56:57 --> Severity: Notice  --> Undefined variable: _POSR /var/www/html/test_ci/application/controllers/query.php 8
ERROR - 2014-05-15 19:57:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 19:57:23 --> Severity: Notice  --> Undefined index: id /var/www/html/test_ci/application/controllers/query.php 16
ERROR - 2014-05-15 19:57:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0"' at line 1
ERROR - 2014-05-15 19:58:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 19:58:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '828670"' at line 1
ERROR - 2014-05-15 19:59:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 19:59:24 --> Severity: Notice  --> Undefined variable: nice /var/www/html/test_ci/application/controllers/query.php 31
ERROR - 2014-05-15 20:00:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 20:00:35 --> Severity: Notice  --> Undefined variable: nice /var/www/html/test_ci/application/controllers/query.php 31
ERROR - 2014-05-15 20:01:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 20:01:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 20:02:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 20:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 20:04:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 20:04:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 20:07:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 20:10:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 20:12:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-15 20:12:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
