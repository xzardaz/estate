<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-05-21 11:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:03:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:03:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:03:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:04:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:04:51 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:05:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:05:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:06:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:06:39 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:08:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:08:00 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:08:12 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:08:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:08:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:08:40 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:08:40 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:08:40 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:09:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:09:33 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:09:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:09:48 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:10:03 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:10:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:10:20 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:11:13 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:11:13 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:11:13 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:11:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:11:55 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:11:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:11:56 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:12:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:12:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:12:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:12:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:12:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:16:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:16:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:17:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:17:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:17:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:17:16 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:17:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:17:40 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:18:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:18:30 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:19:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:19:15 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:19:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:19:32 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:19:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:19:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:19:56 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:22:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:22:17 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:23:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:23:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:23:58 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:23:58 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:23:58 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:24:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:24:13 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:24:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:24:56 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:25:01 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:25:01 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:25:01 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:28:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:28:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:28:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:28:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:28:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:28:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:28:34 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:28:47 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:28:47 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:28:47 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:28:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:29:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:29:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:30:02 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:30:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:30:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:31:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:31:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:32:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:32:27 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:32:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:32:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:32:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:33:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:33:47 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:34:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:34:26 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:35:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:35:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:35:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:35:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:35:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:35:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:35:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:36:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:36:21 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:36:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:36:24 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:37:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:37:37 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:37:37 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:37:37 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:37:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-21 11:37:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-21 11:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:38:00 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:38:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:38:58 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:39:03 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:39:03 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:39:03 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:39:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:39:20 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:39:40 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:39:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:39:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:39:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:40:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:40:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:41:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:41:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:41:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:41:39 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:41:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:41:50 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:49:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:49:52 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:51:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:51:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:53:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:53:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:53:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:53:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:53:06 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:54:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:54:48 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:55:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:55:02 --> 404 Page Not Found --> imgs
ERROR - 2014-05-21 11:56:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-21 11:56:28 --> 404 Page Not Found --> imgs
