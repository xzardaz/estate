<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-05-18 08:25:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-18 08:25:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-18 08:25:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-18 08:25:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-18 08:25:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
