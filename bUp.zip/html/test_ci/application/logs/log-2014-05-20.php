<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-05-20 10:06:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:06:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:07:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:08:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:08:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:08:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:08:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:08:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:08:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:10:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:10:18 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:18 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:18 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:10:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:10:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:10:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:10:26 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:10:27 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:10:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:10:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:52 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:52 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:52 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:10:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:10:55 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:11:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:11:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 10:11:12 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:11:12 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:11:12 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 10:11:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 13:34:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 13:34:50 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 13:34:50 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 13:34:50 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 13:34:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 13:34:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 13:34:51 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 13:57:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 13:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 13:58:20 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 13:58:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 13:59:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 13:59:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 13:59:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:00:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:00:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:00:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:00:36 --> Severity: Notice  --> Undefined property: Browse::$getList /var/www/html/test_ci/system/core/Model.php 51
ERROR - 2014-05-20 14:00:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:00:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:00:46 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:01:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:01:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:01:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:01:26 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:02:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:02:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:04:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:04:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:04:45 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:05:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:05:00 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:05:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:05:05 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:05:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:05:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:07:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:07:13 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:08:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:08:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:08:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:08:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:09:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:09:22 --> Severity: Notice  --> Undefined variable: brief /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 14:09:22 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:09:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:09:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:09:55 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:10:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:10:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:10:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:10:39 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:10:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:10:53 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:11:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:11:37 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:12:01 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:12:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:12:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:13:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:13:22 --> Severity: Notice  --> Undefined property: stdClass::$agLogo /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 14:13:23 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:13:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:13:44 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:14:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:14:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:14:23 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:15:21 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:15:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:15:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:15:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:16:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:16:49 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:18:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:18:46 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:18:46 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:18:46 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:18:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 14:18:48 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 14:19:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:19:30 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:20:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:20:39 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:21:16 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:21:16 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:21:16 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:21:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:31:13 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:33:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:33:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:33:23 --> Query error: Unknown column 'photo.id' in 'on clause'
ERROR - 2014-05-20 14:33:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:33:36 --> Query error: Unknown column 'photo.id' in 'on clause'
ERROR - 2014-05-20 14:34:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:34:06 --> Query error: Unknown column 'photo.id' in 'on clause'
ERROR - 2014-05-20 14:34:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:34:07 --> Query error: Unknown column 'photo.id' in 'on clause'
ERROR - 2014-05-20 14:34:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:34:23 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 14:48:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 14:48:49 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:41:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 18:41:23 --> Severity: Notice  --> Undefined variable: data /var/www/html/test_ci/application/controllers/addoffer.php 12
ERROR - 2014-05-20 18:41:23 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20ERROR - 2014-05-20 18:41:23 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:41:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 18:43:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer_add.php 3
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer_add.php 3
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer_add.php 7
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer_add.php 7
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer_add.php 17
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer_add.php 17
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer_add.php 18
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer_add.php 18
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer_add.php 19
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer_add.php 19
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer_add.php 22
ERROR - 2014-05-20 18:43:11 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer_add.php 22
ERROR - 2014-05-20 18:43:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:44:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 18:45:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 18:45:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 18:45:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 18:45:40 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer_add.php 19
ERROR - 2014-05-20 18:45:40 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer_add.php 19
ERROR - 2014-05-20 18:45:40 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer_add.php 20
ERROR - 2014-05-20 18:45:40 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer_add.php 20
ERROR - 2014-05-20 18:45:40 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer_add.php 23
ERROR - 2014-05-20 18:45:40 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer_add.php 23
ERROR - 2014-05-20 18:45:40 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:46:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 18:46:28 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer_add.php 20
ERROR - 2014-05-20 18:46:28 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer_add.php 20
ERROR - 2014-05-20 18:46:28 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:46:30 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:46:30 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:46:30 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:46:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 18:46:52 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:48:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 18:48:14 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 18:48:46 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:58:24 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:58:24 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 18:58:24 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 19:00:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 19:00:05 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 19:00:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 19:00:28 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 19:01:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 19:01:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 21:07:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 21:07:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 21:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 3
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 7
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 11
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 21
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 22
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 23
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Undefined variable: offer /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 21:07:31 --> Severity: Notice  --> Trying to get property of non-object /var/www/html/test_ci/application/views/offer.php 26
ERROR - 2014-05-20 21:07:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-20 21:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 21:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 21:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 21:07:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-20 21:07:32 --> 404 Page Not Found --> imgs
