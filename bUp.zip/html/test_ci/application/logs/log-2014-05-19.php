<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-05-19 08:46:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:46:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:46:48 --> Severity: Notice  --> Undefined property: Admin::$faq_mdl /var/www/html/test_ci/application/controllers/admin.php 32
ERROR - 2014-05-19 08:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:46:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:46:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:47:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:47:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:47:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:47:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:52:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:52:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:53:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:54:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:54:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:54:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:55:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:56:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:57:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 08:59:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:00:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:00:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:01:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:01:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:03:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:03:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:04:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:05:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:06:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:07:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:08:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:08:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:08:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:11:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:11:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:11:47 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:11:47 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:11:47 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:11:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:11:52 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:13:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:14:00 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:14:00 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:14:00 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:14:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:14:58 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:14:58 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:14:58 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:15:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:15:26 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:15:26 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:15:26 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:15:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:15:48 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:15:48 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:15:48 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:16:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:16:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:16:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:16:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:16:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:16:55 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:16:55 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:16:55 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:20:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:20:23 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:20:23 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:20:23 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:20:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:20:38 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:20:38 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:20:38 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:23:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:37:12 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:37:12 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:37:12 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:37:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:37:39 --> Severity: Notice  --> Undefined index: json /var/www/html/test_ci/application/controllers/browse.php 30
ERROR - 2014-05-19 09:38:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:38:26 --> Severity: Notice  --> Undefined index: json /var/www/html/test_ci/application/controllers/browse.php 30
ERROR - 2014-05-19 09:38:26 --> Severity: Warning  --> array_key_exists() expects exactly 2 parameters, 1 given /var/www/html/test_ci/application/controllers/browse.php 30
ERROR - 2014-05-19 09:38:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:39:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:39:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 09:39:46 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:40:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:40:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 09:40:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 10:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 10:03:04 --> 404 Page Not Found --> browse/asas
ERROR - 2014-05-19 10:03:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 10:03:10 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:04:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:11:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:11:14 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:11:17 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:11:17 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:11:17 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:11:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:11:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:11:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:11:59 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:11:59 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:11:59 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:12:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:12:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:12:33 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:12:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:12:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:12:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:12:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:14:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:14:05 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:14:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:14:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:14:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:14:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:14:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:14:27 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:14:28 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:14:28 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:14:28 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:15:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:15:51 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:15:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:15:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:15:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:16:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:16:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:16:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:16:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:16:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:16:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:16:12 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:16:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:16:33 --> 404 Page Not Found --> brwose
ERROR - 2014-05-19 11:16:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:16:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:16:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:16:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:16:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:16:42 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:17:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:30:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:30:20 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:30:20 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:30:20 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:30:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:30:28 --> 404 Page Not Found --> browse/href
ERROR - 2014-05-19 11:30:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:30:54 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:30:54 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:30:54 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:31:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:31:20 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:31:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:44:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:44:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:44:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:44:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:45:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:45:10 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:45:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:45:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:45:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:45:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:45:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:45:59 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:46:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:48:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:48:27 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:48:27 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:48:27 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:48:28 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:48:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:49:24 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:49:24 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:49:24 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:50:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 11:50:45 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:50:45 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:50:45 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:50:51 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 11:51:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 12:57:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 12:57:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 12:57:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 12:57:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 12:57:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:57:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:57:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:57:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 12:57:37 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:58:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 12:58:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:58:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:58:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:58:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 12:58:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:59:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 12:59:47 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:59:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 12:59:53 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:59:53 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:59:53 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 12:59:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 12:59:54 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:00:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:00:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:00:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:00:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:00:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:00:10 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:03:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:04:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:05:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:08:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:10:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:10:22 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:10:22 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:10:22 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:10:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:10:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:10:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:10:48 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:10:48 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:10:48 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:10:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:11:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:11:37 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:11:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:11:45 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:46 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:46 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:46 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:11:50 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:50 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:50 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:11:52 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:53 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:53 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:53 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:11:55 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:55 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:55 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:11:56 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:11:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:12:00 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:12:00 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:12:00 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:12:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:12:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:12:05 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:12:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:12:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:12:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:12:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:12:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:12:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:12:10 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:12:10 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:12:10 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:12:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:12:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:15:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:16:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:16:34 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:16:34 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:16:34 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:16:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:16:37 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:16:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:19:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:19:06 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:19:06 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:19:06 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:19:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:19:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:19:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:19:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:19:38 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:19:38 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:19:38 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:19:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:19:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:19:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:19:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:19:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:20:01 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:20:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:21:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:32:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:32:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:32:35 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 13:32:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 13:32:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:05:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:10:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:10:46 --> Severity: Notice  --> Undefined variable: jOut /var/www/html/test_ci/application/controllers/faq.php 33
ERROR - 2014-05-19 15:10:46 --> Severity: Notice  --> Undefined variable: out /var/www/html/test_ci/application/controllers/faq.php 33
ERROR - 2014-05-19 15:11:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:11:17 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:11:17 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:11:17 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:11:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:11:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:11:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:11:22 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:11:22 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:11:22 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:11:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:11:27 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:11:30 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:11:30 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:11:30 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:12:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:12:25 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:12:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:12:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:12:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:12:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:12:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:12:40 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:12:40 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:12:40 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:12:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:13:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:13:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:13:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:13:41 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:13:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:13:52 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:13:52 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:13:52 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:13:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:14:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:14:14 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:14:14 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:14:14 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:14:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:14:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:14:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:14:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:14:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:14:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:14:30 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:14:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:14:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:14:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:14:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:14:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:14:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:14:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:14:51 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:14:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:15:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:15:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:15:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:15:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:15:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:15:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:15:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:16:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:16:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:16:45 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:16:45 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:16:45 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:16:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:16:47 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:18:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:18:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:18:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:18:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:18:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:18:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:18:05 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:18:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:18:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:18:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:18:27 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:18:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:18:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:18:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:18:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:18:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:18:36 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:18:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:18:39 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:18:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:20:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:20:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:20:38 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:20:38 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:20:38 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:20:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:20:40 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:20:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:25:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:25:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:25:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:25:33 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:25:33 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:25:33 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:46:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:46:17 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:46:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:46:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:46:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:46:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:47:42 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:47:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:47:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:47:43 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:49:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:49:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:49:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:49:07 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:49:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:49:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:51:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:51:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:51:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:51:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:51:05 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:53:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:53:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:53:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:53:11 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:53:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:53:15 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:53:16 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:53:16 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:53:16 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:54:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:54:19 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:54:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:54:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:54:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:54:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:54:33 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:54:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:54:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:54:53 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:54:53 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:54:53 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:54:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:54:55 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:54:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:55:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:57:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:57:28 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:57:28 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:57:28 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:57:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:57:31 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:57:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:57:57 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:58:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:58:27 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:59:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:59:14 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:59:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:59:24 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:59:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:59:38 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 15:59:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 15:59:56 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:01:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:01:01 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:01:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:01:24 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:01:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:01:40 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:04:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:04:37 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:05:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:05:06 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:05:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:07:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:07:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:07:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:07:04 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:07:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:07:05 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:07:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:07:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:07:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:07:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:08:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:09:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:09:20 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:09:20 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:09:20 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:09:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:09:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:10:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:11:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:11:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:11:45 --> 404 Page Not Found --> browse/user_guide
ERROR - 2014-05-19 16:12:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:12:02 --> 404 Page Not Found --> browse/user_guide
ERROR - 2014-05-19 16:12:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:12:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:12:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:12:08 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:12:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:12:09 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:12:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:12:27 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:12:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:12:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:12:29 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:12:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:17:10 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:17:10 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:17:10 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:18:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-05-19 16:18:05 --> 404 Page Not Found --> imgs
ERROR - 2014-05-19 16:18:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/test_ci/system/database/drivers/mysql/mysql_driver.php 91
