int main()
{
	return 12;
}

bool two(void)
{
	return false;
};
