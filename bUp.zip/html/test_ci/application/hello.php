<?php



$hello="hi"
$hi2=array();

?>
